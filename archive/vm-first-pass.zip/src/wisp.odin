package main

import "core:fmt"
import "core:strconv"
import "core:strings"


// Value model ====================================================================================

ObjectKind :: enum u8 {
	STRING,
	SYMBOL,
	LIST,
	VECTOR,
	NATIVE_FUNCTION,
}

// Every heap object starts with this header so ^Object can dispatch by kind.
Object :: struct {
	kind: ObjectKind,
}

StringObject :: struct {
	header: Object,
	text:   string,
}

SymbolObject :: struct {
	header: Object,
	text:   string,
}

ListObject :: struct {
	header: Object,

	// Lists are immutable Wisp values. This storage is built once and is not
	// mutated by language operations.
	items: [dynamic]Value,
}

VectorObject :: struct {
	header: Object,
	items:  [dynamic]Value,
}

// The zero value of this union represents Wisp nil.
Value :: union {
	bool,
	i64,
	f64,
	^Object,
}

NativeProc :: proc(vm: ^VM, args: []Value) -> Value

NativeFunctionObject :: struct {
	header: Object,
	native: NativeProc,
}


// VM data ========================================================================================

Op :: enum u8 {
	LOAD_NIL,
	LOAD_TRUE,
	LOAD_FALSE,
	LOAD_CONST,

	MOVE,

	GET_GLOBAL,
	SET_GLOBAL,

	CALL,

	MAKE_VECTOR,
	SET_VECTOR,

	RETURN,
}

InstABC :: bit_field u32 {
	op: Op | 8,
	a:  u8 | 8,
	b:  u8 | 8,
	c:  u8 | 8,
}

InstABx :: bit_field u32 {
	op: Op  | 8,
	a:  u8  | 8,
	b:  u16 | 16,
}

Code :: struct {
	bytecode:         [dynamic]u32,
	constants:        [dynamic]Value,
	frame_slot_count: int,
}

GlobalBinding :: struct {
	symbol: ^SymbolObject,
	value:  Value,
}

Active_Code: Code

VM :: struct {
	slots:        [dynamic]Value,
	globals:      [dynamic]GlobalBinding,
	error_string: string,
}


// Symbol interning ===============================================================================

Symbol_Table: [dynamic]^SymbolObject

// Equal symbol text always returns the same SymbolObject pointer.
intern_symbol :: proc(text: string) -> ^SymbolObject {
	for symbol in Symbol_Table {
		if symbol.text == text { return symbol }
	}

	symbol := new(SymbolObject)
	symbol.header.kind = .SYMBOL
	// Copy text because interned symbols outlive Reader.source.
	symbol.text = strings.clone(text)

	append(&Symbol_Table, symbol)
	return symbol
}


// Object construction ============================================================================

new_string_object :: proc(text: string) -> ^StringObject {
	object := new(StringObject)
	object.header.kind = .STRING
	// Copy text because the returned object may outlive Reader.source.
	object.text = strings.clone(text)
	return object
}

// Aggregate constructors take ownership of the dynamic item array.
new_list_object :: proc(items: [dynamic]Value) -> ^ListObject {
	object := new(ListObject)
	object.header.kind = .LIST
	object.items = items
	return object
}

new_vector_object :: proc(items: [dynamic]Value) -> ^VectorObject {
	object := new(VectorObject)
	object.header.kind = .VECTOR
	object.items = items
	return object
}


// Reader state ===================================================================================

// Reader is single-active; error_string latches failure until the next read_source.
// Values returned after failure are disposable placeholders that callers ignore.
Reader := struct {
	source: string,
	index: int,
	error_string: string,
}{}


// Reader errors ==================================================================================

reader_error :: proc(message: string) {
	Reader.error_string = fmt.tprintf("read error at byte %d: %s", Reader.index, message)
}


// Reader character utilities =====================================================================

is_digit :: proc(ch: u8) -> bool {
	return ch >= '0' && ch <= '9'
}

is_whitespace :: proc(ch: u8) -> bool {
	return ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n'
}

is_delimiter :: proc(ch: u8) -> bool {
	return is_whitespace(ch) ||
	       ch == '(' ||
	       ch == ')' ||
	       ch == '"' ||
	       ch == '\'' ||
	       ch == ';' ||
	       ch == '[' ||
	       ch == ']'
}

// Leaves Reader.index at the next form byte or the end of source.
skip_trivia :: proc() {
	for Reader.index < len(Reader.source) {
		ch := Reader.source[Reader.index]

		if is_whitespace(ch) {
			Reader.index += 1
			continue
		}

		if ch == ';' {
			for Reader.index < len(Reader.source) && Reader.source[Reader.index] != '\n' {
				Reader.index += 1
			}
			continue
		}

		break
	}
}


// Reader scans ===================================================================================

read_atom :: proc() -> Value {
	// The caller positions Reader.index at the first byte of an atom.
	token_start := Reader.index

	// Stop before the delimiter so the enclosing reader can consume it.
	for Reader.index < len(Reader.source) && !is_delimiter(Reader.source[Reader.index]) {
		Reader.index += 1
	}

	text := Reader.source[token_start:Reader.index]
	if text == "nil" { return Value{} }
	if text == "true" { return Value(bool(true)) }
	if text == "false" { return Value(bool(false)) }

	// Numeric-looking atoms start with a digit, .digit, -digit, or - followed by a dot.
	looks_numeric :=
		is_digit(text[0]) ||
		(len(text) > 1 && text[0] == '.' && is_digit(text[1])) ||
		(len(text) > 1 && text[0] == '-' &&
			(is_digit(text[1]) || text[1] == '.'))

	// Malformed numeric-looking atoms are errors; other atoms become symbols.
	if looks_numeric {
		number_index := 0
		is_negative := false

		if text[number_index] == '-' {
			is_negative = true
			number_index += 1
		}

		// Scan decimal digits on either side of an optional decimal point.
		digit_count := 0
		for number_index < len(text) && is_digit(text[number_index]) {
			digit_count += 1
			number_index += 1
		}

		is_float := number_index < len(text) && text[number_index] == '.'
		if is_float {
			number_index += 1

			for number_index < len(text) && is_digit(text[number_index]) {
				digit_count += 1
				number_index += 1
			}
		}

		// Valid numbers contain a digit and consume the entire atom.
		if digit_count == 0 || number_index != len(text) {
			reader_error("invalid number literal")
			return Value{}
		}

		// Odin converts the value only after Wisp accepts its spelling.
		if is_float {
			float_value, float_ok := strconv.parse_f64(text)
			if !float_ok {
				reader_error("float literal out of range")
				return Value{}
			}

			return Value(float_value)
		}

		// Unsigned magnitude handles the extra negative i64 value without overflow.
		magnitude_limit := u64(max(i64))
		if is_negative {
			magnitude_limit += 1
		}

		magnitude: u64
		digit_index := 1 if is_negative else 0

		for digit_index < len(text) {
			digit := u64(text[digit_index] - '0')

			if magnitude > (magnitude_limit - digit) / 10 {
				reader_error("integer literal out of range")
				return Value{}
			}

			magnitude = magnitude * 10 + digit
			digit_index += 1
		}

		if is_negative {
			if magnitude == magnitude_limit { return Value(min(i64)) }
			return Value(-i64(magnitude))
		}

		return Value(i64(magnitude))
	}

	return Value(cast(^Object)intern_symbol(text))
}

read_string :: proc() -> Value {
	// current char is '"'
	Reader.index += 1
	start := Reader.index

	for Reader.index < len(Reader.source) {
		ch := Reader.source[Reader.index]

		if ch == '\n' || ch == '\r' {
			reader_error("unterminated string")
			return Value{}
		}

		if ch == '\\' {
			reader_error("string escapes not implemented")
			return Value{}
		}

		if ch == '"' {
			text := Reader.source[start:Reader.index]
			Reader.index += 1
			return Value(cast(^Object)new_string_object(text))
		}

		Reader.index += 1
	}

	reader_error("unterminated string")
	return Value{}
}

read_list :: proc() -> Value {
	// current char is '('
	Reader.index += 1

	// Build locally; the ListObject takes ownership only after the closing ')'.
	items := make([dynamic]Value)

	for {
		skip_trivia()

		if Reader.index >= len(Reader.source) {
			reader_error("unterminated list")
			delete(items)
			return Value{}
		}

		if Reader.source[Reader.index] == ')' {
			Reader.index += 1
			return Value(cast(^Object)new_list_object(items))
		}

		item := read_form()
		if Reader.error_string != "" {
			delete(items)
			return Value{}
		}

		append(&items, item)
	}
}

read_vector :: proc() -> Value {
	// current char is '['
	Reader.index += 1

	// Build locally; the VectorObject takes ownership only after the closing ']'.
	items := make([dynamic]Value)

	for {
		skip_trivia()

		if Reader.index >= len(Reader.source) {
			reader_error("unterminated vector")
			delete(items)
			return Value{}
		}

		if Reader.source[Reader.index] == ']' {
			Reader.index += 1
			return Value(cast(^Object)new_vector_object(items))
		}

		item := read_form()
		if Reader.error_string != "" {
			delete(items)
			return Value{}
		}

		append(&items, item)
	}
}

read_form :: proc() -> Value {
	// Whitespace is already skipped; this proc only dispatches the current form.
	ch := Reader.source[Reader.index]

	switch ch {
	case '(':
		return read_list()

	case ')':
		reader_error("unexpected ')'")
		return Value{}

	case '"':
		return read_string()

	case '\'':
		reader_error("quote not implemented")
		return Value{}

	case '[':
		return read_vector()

	case ']':
		reader_error("unexpected ']'")
		return Value{}

	case:
		return read_atom()
	}
}

read_all_forms :: proc() -> [dynamic]Value {
	// This loop owns whitespace between top-level forms.
	forms := make([dynamic]Value)

	for {
		skip_trivia()

		if Reader.index >= len(Reader.source) {
			break
		}

		form := read_form()
		if Reader.error_string != "" {
			return forms
		}

		append(&forms, form)
	}

	return forms
}

read_source :: proc(source: string) -> ([dynamic]Value, string) {
	// Reset the singleton reader for one complete source operation.
	Reader.source = source
	Reader.index = 0
	Reader.error_string = ""

	forms := read_all_forms()
	if Reader.error_string != "" {
		delete(forms)
		return nil, Reader.error_string
	}

	return forms, ""
}


// Debug tree printer =============================================================================

// Depth is the two-space indentation level for this value and its children.
debug_print_value_tree :: proc(value: Value, depth: int) {
	for _ in 0..<depth {
		fmt.print("  ")
	}

	if value == nil {
		fmt.println("Nil")
		return
	}

	switch v in value {
	case bool:
		fmt.printf("Bool(%v)\n", v)

	case i64:
		fmt.printf("Int(%d)\n", v)

	case f64:
		fmt.printf("Float(%.15g)\n", v)

	case ^Object:
		switch v.kind {
		case .STRING:
			object := cast(^StringObject)v
			fmt.printf("String(\"%s\")\n", object.text)

		case .SYMBOL:
			object := cast(^SymbolObject)v
			fmt.printf("Symbol(`%s`)\n", object.text)

		case .LIST:
			object := cast(^ListObject)v
			fmt.printf("List(%d)\n", len(object.items))

			for item in object.items {
				debug_print_value_tree(item, depth + 1)
			}

		case .VECTOR:
			object := cast(^VectorObject)v
			fmt.printf("Vector(%d)\n", len(object.items))

			for item in object.items {
				debug_print_value_tree(item, depth + 1)
			}

		case .NATIVE_FUNCTION:
			assert(false, "native function in source tree")
		}
	}
}

debug_print_source_tree :: proc(forms: [dynamic]Value) {
	for i := 0; i < len(forms); i += 1 {
		debug_print_value_tree(forms[i], 0)

		if i + 1 < len(forms) {
			fmt.println()
		}
	}
}


// Runtime display ================================================================================

// parents contains only composite objects currently above this value.
print_value_inner :: proc(value: Value, parents: ^[dynamic]^Object) {
	if value == nil {
		fmt.print("nil")
		return
	}

	switch v in value {
	case bool:
		fmt.print(v)

	case i64:
		fmt.print(v)

	case f64:
		text := fmt.tprintf("%.15g", v)
		fmt.print(text)

		whole_number_text := true
		for i := 0; i < len(text); i += 1 {
			if i == 0 && text[i] == '-' {
				continue
			}
			if !is_digit(text[i]) {
				whole_number_text = false
				break
			}
		}

		if whole_number_text {
			fmt.print(".0")
		}

	case ^Object:
		switch v.kind {
		case .STRING:
			object := cast(^StringObject)v
			fmt.print(object.text)

		case .SYMBOL:
			object := cast(^SymbolObject)v
			fmt.printf("<symbol %s>", object.text)

		case .LIST:
			for parent in parents {
				if parent == v {
					fmt.print("(...)")
					return
				}
			}
			append(parents, v)

			object := cast(^ListObject)v
			fmt.print("(")
			for i := 0; i < len(object.items); i += 1 {
				if i > 0 {
					fmt.print(" ")
				}
				print_value_inner(object.items[i], parents)
			}
			fmt.print(")")

			pop(parents)

		case .VECTOR:
			for parent in parents {
				if parent == v {
					fmt.print("[...]")
					return
				}
			}
			append(parents, v)

			object := cast(^VectorObject)v
			fmt.print("[")
			for i := 0; i < len(object.items); i += 1 {
				if i > 0 {
					fmt.print(" ")
				}
				print_value_inner(object.items[i], parents)
			}
			fmt.print("]")

			pop(parents)

		case .NATIVE_FUNCTION:
			fmt.print("<function>")

		case:
			assert(false, "invalid object tag")
		}
	}
}

print_value :: proc(value: Value) {
	parents := make([dynamic]^Object)
	print_value_inner(value, &parents)
	delete(parents)
}


// Runtime errors =================================================================================

runtime_error :: proc(vm: ^VM, message: string) {
	vm.error_string = fmt.tprintf("runtime error: %s", message)
}


// Globals ========================================================================================

find_global :: proc(vm: ^VM, symbol: ^SymbolObject) -> (int, bool) {
	for i := 0; i < len(vm.globals); i += 1 {
		if vm.globals[i].symbol == symbol {
			return i, true
		}
	}

	return -1, false
}

// Native globals are ordinary mutable Wisp bindings.
bind_native_global :: proc(vm: ^VM, name: string, native: NativeProc) -> int {
	symbol := intern_symbol(name)
	index, found := find_global(vm, symbol)

	if !found {
		append(&vm.globals, GlobalBinding{
			symbol = symbol,
		})
		index = len(vm.globals) - 1
	}

	function := new(NativeFunctionObject)
	function.header.kind = .NATIVE_FUNCTION
	function.native = native

	vm.globals[index].value = Value(cast(^Object)function)
	return index
}


// Code construction ==============================================================================

begin_code :: proc() {
	Active_Code = Code{
		bytecode         = make([dynamic]u32),
		constants        = make([dynamic]Value),
		frame_slot_count = 0,
	}
}

// The returned Code takes ownership of the active dynamic arrays.
end_code :: proc() -> Code {
	code := Active_Code
	Active_Code = Code{}
	return code
}


// Constants ======================================================================================

const_value :: proc(value: Value) -> int {
	append(&Active_Code.constants, value)
	return len(Active_Code.constants) - 1
}

const_int :: proc(value: i64) -> int {
	return const_value(Value(value))
}

const_float :: proc(value: f64) -> int {
	return const_value(Value(value))
}

const_string :: proc(text: string) -> int {
	return const_value(Value(cast(^Object)new_string_object(text)))
}


// Bytecode emission ==============================================================================

// frame_slot_count is the highest touched frame slot plus one.
record_slots :: proc(slots: ..int) {
	for slot in slots {
		assert(slot >= 0 && slot <= int(max(u8)), "frame slot does not fit u8")

		needed_slot_count := slot + 1
		if needed_slot_count > Active_Code.frame_slot_count {
			Active_Code.frame_slot_count = needed_slot_count
		}
	}
}

emit_ABC :: proc(op: Op, a, b, c: int) {
	append(&Active_Code.bytecode, u32(InstABC{
		op = op,
		a  = u8(a),
		b  = u8(b),
		c  = u8(c),
	}))
}

emit_ABx :: proc(op: Op, a, b: int) {
	append(&Active_Code.bytecode, u32(InstABx{
		op = op,
		a  = u8(a),
		b  = u16(b),
	}))
}

emit_load_nil :: proc(dst: int) {
	record_slots(dst)
	emit_ABx(.LOAD_NIL, dst, 0)
}

emit_load_true :: proc(dst: int) {
	record_slots(dst)
	emit_ABx(.LOAD_TRUE, dst, 0)
}

emit_load_false :: proc(dst: int) {
	record_slots(dst)
	emit_ABx(.LOAD_FALSE, dst, 0)
}

emit_load_const :: proc(dst, constant_index: int) {
	record_slots(dst)
	emit_ABx(.LOAD_CONST, dst, constant_index)
}

emit_move :: proc(dst, src: int) {
	record_slots(dst, src)
	emit_ABC(.MOVE, dst, src, 0)
}

emit_get_global :: proc(dst, global_index: int) {
	record_slots(dst)
	emit_ABx(.GET_GLOBAL, dst, global_index)
}

emit_set_global :: proc(global_index, src: int) {
	record_slots(src)
	emit_ABx(.SET_GLOBAL, src, global_index)
}

emit_call :: proc(base, argument_count: int) {
	assert(argument_count >= 0 && argument_count <= int(max(u8)), "call argument count does not fit u8")

	record_slots(base)
	if argument_count > 0 {
		record_slots(base + argument_count)
	}
	emit_ABC(.CALL, base, argument_count, 0)
}

emit_make_vector :: proc(dst, first_slot, count: int) {
	assert(count >= 0 && count <= int(max(u8)), "vector element count does not fit u8")

	record_slots(dst)
	if count > 0 {
		record_slots(first_slot + count - 1)
	}
	emit_ABC(.MAKE_VECTOR, dst, first_slot, count)
}

emit_set_vector :: proc(vector_slot, index_slot, value_slot: int) {
	record_slots(vector_slot, index_slot, value_slot)
	emit_ABC(.SET_VECTOR, vector_slot, index_slot, value_slot)
}

emit_return :: proc(src: int) {
	record_slots(src)
	emit_ABx(.RETURN, src, 0)
}


// Native builtins ================================================================================

native_add :: proc(vm: ^VM, args: []Value) -> Value {
	if len(args) < 2 {
		runtime_error(vm, "+ expects two or more arguments")
		return Value{}
	}

	all_int := true
	int_total: i64
	float_total: f64

	for arg in args {
		switch v in arg {
		case i64:
			if all_int {
				int_total += v
			} else {
				float_total += f64(v)
			}

		case f64:
			if all_int {
				float_total = f64(int_total)
				all_int = false
			}
			float_total += v

		case bool, ^Object:
			runtime_error(vm, "+ expects numbers")
			return Value{}
		}
	}

	if all_int {
		return Value(int_total)
	}

	return Value(float_total)
}

native_print :: proc(vm: ^VM, args: []Value) -> Value {
	if len(args) != 1 {
		runtime_error(vm, "print expects one argument")
		return Value{}
	}

	print_value(args[0])
	fmt.println()
	return Value{}
}


// VM execution ===================================================================================

run :: proc(vm: ^VM, code: ^Code) -> (Value, string) {
	delete(vm.slots)
	vm.slots = make([dynamic]Value, code.frame_slot_count)
	vm.error_string = ""

	ip := 0

	for {
		assert(ip < len(code.bytecode), "code ended without RETURN")

		word := code.bytecode[ip]
		ip += 1

		op := InstABC(word).op

		switch op {
		case .LOAD_NIL:
			inst := InstABx(word)
			vm.slots[int(inst.a)] = Value{}

		case .LOAD_TRUE:
			inst := InstABx(word)
			vm.slots[int(inst.a)] = Value(bool(true))

		case .LOAD_FALSE:
			inst := InstABx(word)
			vm.slots[int(inst.a)] = Value(bool(false))

		case .LOAD_CONST:
			inst := InstABx(word)
			constant_index := int(inst.b)
			assert(constant_index < len(code.constants), "constant index out of range")
			vm.slots[int(inst.a)] = code.constants[constant_index]

		case .MOVE:
			inst := InstABC(word)
			vm.slots[int(inst.a)] = vm.slots[int(inst.b)]

		case .GET_GLOBAL:
			inst := InstABx(word)
			global_index := int(inst.b)
			assert(global_index < len(vm.globals), "global index out of range")
			vm.slots[int(inst.a)] = vm.globals[global_index].value

		case .SET_GLOBAL:
			inst := InstABx(word)
			global_index := int(inst.b)
			assert(global_index < len(vm.globals), "global index out of range")
			vm.globals[global_index].value = vm.slots[int(inst.a)]

		case .CALL:
			inst := InstABC(word)
			base := int(inst.a)
			argument_count := int(inst.b)
			callee := vm.slots[base]

			callee_object, callee_is_object := callee.(^Object)
			if !callee_is_object {
				runtime_error(vm, "value is not callable")
				return Value{}, vm.error_string
			}

			switch callee_object.kind {
			case .NATIVE_FUNCTION:
				function := cast(^NativeFunctionObject)callee_object
				args := vm.slots[base + 1:base + 1 + argument_count]

				result := function.native(vm, args)
				if vm.error_string != "" {
					return Value{}, vm.error_string
				}

				vm.slots[base] = result

			case .VECTOR:
				if argument_count != 1 {
					runtime_error(vm, "vector call expects one index")
					return Value{}, vm.error_string
				}

				index, index_is_int := vm.slots[base + 1].(i64)
				if !index_is_int {
					runtime_error(vm, "vector index must be int")
					return Value{}, vm.error_string
				}

				vector := cast(^VectorObject)callee_object
				if index < 0 || index >= i64(len(vector.items)) {
					runtime_error(vm, "vector index out of range")
					return Value{}, vm.error_string
				}

				vm.slots[base] = vector.items[int(index)]

			case .STRING, .SYMBOL, .LIST:
				runtime_error(vm, "value is not callable")
				return Value{}, vm.error_string
			}

		case .MAKE_VECTOR:
			inst := InstABC(word)
			dst := int(inst.a)
			first_slot := int(inst.b)
			count := int(inst.c)

			items := make([dynamic]Value)
			for i := 0; i < count; i += 1 {
				append(&items, vm.slots[first_slot + i])
			}

			vm.slots[dst] = Value(cast(^Object)new_vector_object(items))

		case .SET_VECTOR:
			inst := InstABC(word)
			vector_value := vm.slots[int(inst.a)]
			index_value := vm.slots[int(inst.b)]
			new_value := vm.slots[int(inst.c)]

			vector_object, vector_is_object := vector_value.(^Object)
			if !vector_is_object || vector_object.kind != .VECTOR {
				runtime_error(vm, "vector set receiver must be vector")
				return Value{}, vm.error_string
			}

			index, index_is_int := index_value.(i64)
			if !index_is_int {
				runtime_error(vm, "vector set index must be int")
				return Value{}, vm.error_string
			}

			vector := cast(^VectorObject)vector_object
			if index < 0 || index >= i64(len(vector.items)) {
				runtime_error(vm, "vector index out of range")
				return Value{}, vm.error_string
			}

			vector.items[int(index)] = new_value

		case .RETURN:
			inst := InstABx(word)
			return vm.slots[int(inst.a)], ""

		case:
			assert(false, "invalid opcode")
		}
	}
}


// Program entry ==================================================================================

main :: proc() {
	source :=
	`
	(do
	  (def label "dog")
	  (def values [10 20 30])

	  (set (values 1)
	    (+ (values 0) (values 2)))

	  (print label)
	  (print values)
	  (print (values 1)))
	`

	forms, read_error := read_source(source)
	if read_error != "" {
		fmt.eprintln(read_error)
		return
	}

	debug_tree := true
	if debug_tree {
		fmt.println("SOURCE:")
		fmt.print(source)
		fmt.println()

		fmt.println("TREE:")
		debug_print_source_tree(forms)
		fmt.println()
	}

	vm: VM
	vm.globals = make([dynamic]GlobalBinding)

	plus_index := bind_native_global(&vm, "+", native_add)
	print_index := bind_native_global(&vm, "print", native_print)

	begin_code()

	label_constant := const_string("dog")
	c0 := const_int(0)
	c1 := const_int(1)
	c2 := const_int(2)
	c10 := const_int(10)
	c20 := const_int(20)
	c30 := const_int(30)

	// Build the source above by hand.
	//
	// slot 0 = label
	// slot 1 = values
	// slot 2..7 = call and expression temporaries
	emit_load_const(0, label_constant)

	emit_load_const(4, c10)
	emit_load_const(5, c20)
	emit_load_const(6, c30)
	emit_make_vector(1, 4, 3)

	// values[1] = values[0] + values[2]
	emit_get_global(4, plus_index)

	emit_move(5, 1)
	emit_load_const(6, c0)
	emit_call(5, 1)

	emit_move(6, 1)
	emit_load_const(7, c2)
	emit_call(6, 1)

	emit_call(4, 2)
	emit_load_const(7, c1)
	emit_set_vector(1, 7, 4)

	// print label
	emit_get_global(2, print_index)
	emit_move(3, 0)
	emit_call(2, 1)

	// print values
	emit_get_global(2, print_index)
	emit_move(3, 1)
	emit_call(2, 1)

	// print values[1]
	emit_get_global(2, print_index)
	emit_move(3, 1)
	emit_load_const(4, c1)
	emit_call(3, 1)
	emit_call(2, 1)
	emit_return(2)

	code := end_code()

	_, run_error := run(&vm, &code)
	if run_error != "" {
		fmt.eprintln(run_error)
		return
	}
}
