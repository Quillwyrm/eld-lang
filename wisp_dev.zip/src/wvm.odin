package main

Op :: enum {
    LOAD_CONST,             // dst, const_idx
    GET_SLOT,               // dst, slot
    SET_SLOT,               // slot, src
    GET_GLOBAL,             // dst, global_idx
    SET_GLOBAL,             // global_idx, src
    CALL,                   // base, arg_count
    MAKE_VECTOR,            // dst, first_slot count
    VECTOR_GET,             // dst, vec_slot idx_slot
    VECTOR_SET,             // vec_slot, idx_slot, val_slot
    RETURN,                 // src / HALT src
    MOVE,                   // dst, src
}
