package main

import "core:fmt"
import "core:strconv"
import "core:strings"


// Value model ====================================================================================

ObjectKind :: enum u8 {
	STRING,
	SYMBOL,
	LIST,
	VECTOR,
}

// Every heap object starts with this header so ^Object can dispatch by kind.
Object :: struct {
	kind: ObjectKind,
}

StringObject :: struct {
	header: Object,
	text:   string,
}

SymbolObject :: struct {
	header: Object,
	text:   string,
}

ListObject :: struct {
	header: Object,

	// Lists are immutable Wisp values. This storage is built once and is not
	// mutated by language operations.
	items: [dynamic]Value,
}

VectorObject :: struct {
	header: Object,
	items:  [dynamic]Value,
}

// The zero value of this union represents Wisp nil.
Value :: union {
	bool,
	i64,
	f64,
	^Object,
}


// Symbol interning ===============================================================================

Symbol_Table: [dynamic]^SymbolObject

// Equal symbol text always returns the same SymbolObject pointer.
intern_symbol :: proc(text: string) -> ^SymbolObject {
	for symbol in Symbol_Table {
		if symbol.text == text { return symbol }
	}

	symbol := new(SymbolObject)
	symbol.header.kind = .SYMBOL
	// Copy text because interned symbols outlive Reader.source.
	symbol.text = strings.clone(text)

	append(&Symbol_Table, symbol)
	return symbol
}


// Object construction ============================================================================

new_string_object :: proc(text: string) -> ^StringObject {
	object := new(StringObject)
	object.header.kind = .STRING
	// Copy text because the returned object may outlive Reader.source.
	object.text = strings.clone(text)
	return object
}

// Aggregate constructors take ownership of the dynamic item array.
new_list_object :: proc(items: [dynamic]Value) -> ^ListObject {
	object := new(ListObject)
	object.header.kind = .LIST
	object.items = items
	return object
}

new_vector_object :: proc(items: [dynamic]Value) -> ^VectorObject {
	object := new(VectorObject)
	object.header.kind = .VECTOR
	object.items = items
	return object
}


// Reader state ===================================================================================

// Reader is single-active; error_string latches failure until the next read_source.
// Values returned after failure are disposable placeholders that callers ignore.
Reader := struct {
	source: string,
	index: int,
	error_string: string,
}{}


// Reader errors ==================================================================================

reader_error :: proc(message: string) {
	Reader.error_string = fmt.tprintf("read error at byte %d: %s", Reader.index, message)
}


// Reader character utilities =====================================================================

is_digit :: proc(ch: u8) -> bool {
	return ch >= '0' && ch <= '9'
}

is_whitespace :: proc(ch: u8) -> bool {
	return ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n'
}

is_delimiter :: proc(ch: u8) -> bool {
	return is_whitespace(ch) ||
	       ch == '(' ||
	       ch == ')' ||
	       ch == '"' ||
	       ch == '\'' ||
	       ch == ';' ||
	       ch == '[' ||
	       ch == ']'
}

// Leaves Reader.index at the next form byte or the end of source.
skip_trivia :: proc() {
	for Reader.index < len(Reader.source) {
		ch := Reader.source[Reader.index]

		if is_whitespace(ch) {
			Reader.index += 1
			continue
		}

		if ch == ';' {
			for Reader.index < len(Reader.source) && Reader.source[Reader.index] != '\n' {
				Reader.index += 1
			}
			continue
		}

		break
	}
}


// Reader scans ===================================================================================

read_atom :: proc() -> Value {
	// The caller positions Reader.index at the first byte of an atom.
	token_start := Reader.index

	// Stop before the delimiter so the enclosing reader can consume it.
	for Reader.index < len(Reader.source) && !is_delimiter(Reader.source[Reader.index]) {
		Reader.index += 1
	}

	text := Reader.source[token_start:Reader.index]
	if text == "nil" { return Value{} }
	if text == "true" { return Value(bool(true)) }
	if text == "false" { return Value(bool(false)) }

	// Numeric-looking atoms start with a digit, .digit, -digit, or - followed by a dot.
	looks_numeric :=
		is_digit(text[0]) ||
		(len(text) > 1 && text[0] == '.' && is_digit(text[1])) ||
		(len(text) > 1 && text[0] == '-' &&
			(is_digit(text[1]) || text[1] == '.'))

	// Malformed numeric-looking atoms are errors; other atoms become symbols.
	if looks_numeric {
		number_index := 0
		is_negative := false

		if text[number_index] == '-' {
			is_negative = true
			number_index += 1
		}

		// Scan decimal digits on either side of an optional decimal point.
		digit_count := 0
		for number_index < len(text) && is_digit(text[number_index]) {
			digit_count += 1
			number_index += 1
		}

		is_float := number_index < len(text) && text[number_index] == '.'
		if is_float {
			number_index += 1

			for number_index < len(text) && is_digit(text[number_index]) {
				digit_count += 1
				number_index += 1
			}
		}

		// Valid numbers contain a digit and consume the entire atom.
		if digit_count == 0 || number_index != len(text) {
			reader_error("invalid number literal")
			return Value{}
		}

		// Odin converts the value only after Wisp accepts its spelling.
		if is_float {
			float_value, float_ok := strconv.parse_f64(text)
			if !float_ok {
				reader_error("float literal out of range")
				return Value{}
			}

			return Value(float_value)
		}

		// Unsigned magnitude handles the extra negative i64 value without overflow.
		magnitude_limit := u64(max(i64))
		if is_negative {
			magnitude_limit += 1
		}

		magnitude: u64
		digit_index := 1 if is_negative else 0

		for digit_index < len(text) {
			digit := u64(text[digit_index] - '0')

			if magnitude > (magnitude_limit - digit) / 10 {
				reader_error("integer literal out of range")
				return Value{}
			}

			magnitude = magnitude * 10 + digit
			digit_index += 1
		}

		if is_negative {
			if magnitude == magnitude_limit { return Value(min(i64)) }
			return Value(-i64(magnitude))
		}

		return Value(i64(magnitude))
	}

	return Value(cast(^Object)intern_symbol(text))
}

read_string :: proc() -> Value {
	// current char is '"'
	Reader.index += 1
	start := Reader.index

	for Reader.index < len(Reader.source) {
		ch := Reader.source[Reader.index]

		if ch == '\n' || ch == '\r' {
			reader_error("unterminated string")
			return Value{}
		}

		if ch == '\\' {
			reader_error("string escapes not implemented")
			return Value{}
		}

		if ch == '"' {
			text := Reader.source[start:Reader.index]
			Reader.index += 1
			return Value(cast(^Object)new_string_object(text))
		}

		Reader.index += 1
	}

	reader_error("unterminated string")
	return Value{}
}

read_list :: proc() -> Value {
	// current char is '('
	Reader.index += 1

	// Build locally; the ListObject takes ownership only after the closing ')'.
	items := make([dynamic]Value)

	for {
		skip_trivia()

		if Reader.index >= len(Reader.source) {
			reader_error("unterminated list")
			delete(items)
			return Value{}
		}

		if Reader.source[Reader.index] == ')' {
			Reader.index += 1
			return Value(cast(^Object)new_list_object(items))
		}

		item := read_form()
		if Reader.error_string != "" {
			delete(items)
			return Value{}
		}

		append(&items, item)
	}
}

read_vector :: proc() -> Value {
	// current char is '['
	Reader.index += 1

	// Build locally; the VectorObject takes ownership only after the closing ']'.
	items := make([dynamic]Value)

	for {
		skip_trivia()

		if Reader.index >= len(Reader.source) {
			reader_error("unterminated vector")
			delete(items)
			return Value{}
		}

		if Reader.source[Reader.index] == ']' {
			Reader.index += 1
			return Value(cast(^Object)new_vector_object(items))
		}

		item := read_form()
		if Reader.error_string != "" {
			delete(items)
			return Value{}
		}

		append(&items, item)
	}
}

read_form :: proc() -> Value {
	// Whitespace is already skipped; this proc only dispatches the current form.
	ch := Reader.source[Reader.index]

	switch ch {
	case '(':
		return read_list()

	case ')':
		reader_error("unexpected ')'")
		return Value{}

	case '"':
		return read_string()

	case '\'':
		reader_error("quote not implemented")
		return Value{}

	case '[':
		return read_vector()

	case ']':
		reader_error("unexpected ']'")
		return Value{}

	case:
		return read_atom()
	}
}

read_all_forms :: proc() -> [dynamic]Value {
	// This loop owns whitespace between top-level forms.
	forms := make([dynamic]Value)

	for {
		skip_trivia()

		if Reader.index >= len(Reader.source) {
			break
		}

		form := read_form()
		if Reader.error_string != "" {
			return forms
		}

		append(&forms, form)
	}

	return forms
}

read_source :: proc(source: string) -> ([dynamic]Value, string) {
	// Reset the singleton reader for one complete source operation.
	Reader.source = source
	Reader.index = 0
	Reader.error_string = ""

	forms := read_all_forms()
	if Reader.error_string != "" {
		delete(forms)
		return nil, Reader.error_string
	}

	return forms, ""
}


// Debug tree printer =============================================================================

// Depth is the two-space indentation level for this value and its children.
debug_print_value_tree :: proc(value: Value, depth: int) {
	for _ in 0..<depth {
		fmt.print("  ")
	}

	if value == nil {
		fmt.println("Nil")
		return
	}

	switch v in value {
	case bool:
		fmt.printf("Bool(%v)\n", v)

	case i64:
		fmt.printf("Int(%d)\n", v)

	case f64:
		fmt.printf("Float(%.15g)\n", v)

	case ^Object:
		switch v.kind {
		case .STRING:
			object := cast(^StringObject)v
			fmt.printf("String(\"%s\")\n", object.text)

		case .SYMBOL:
			object := cast(^SymbolObject)v
			fmt.printf("Symbol(`%s`)\n", object.text)

		case .LIST:
			object := cast(^ListObject)v
			fmt.printf("List(%d)\n", len(object.items))

			for item in object.items {
				debug_print_value_tree(item, depth + 1)
			}

		case .VECTOR:
			object := cast(^VectorObject)v
			fmt.printf("Vector(%d)\n", len(object.items))

			for item in object.items {
				debug_print_value_tree(item, depth + 1)
			}

		case:
			assert(false, "invalid object tag")
		}
	}
}

debug_print_source_tree :: proc(forms: [dynamic]Value) {
	for i := 0; i < len(forms); i += 1 {
		debug_print_value_tree(forms[i], 0)

		if i + 1 < len(forms) {
			fmt.println()
		}
	}
}


// Test entry =====================================================================================

main :: proc() {
	source :=
	`
    ;secrets
    (def v [ a b "c" 1 2. .3 -2 -2.0 ])
    (def osc
        (sin 220))

    (def filt
        (lpf osc 1200))

    (def voice
        (* 0.2 filt))

    (play voice)
	`

	forms, read_error := read_source(source)
	if read_error != "" {
		fmt.eprintln(read_error)
		return
	}

	fmt.println("SOURCE:")
	fmt.print(source)
	fmt.println()

	fmt.println("TREE:")
	debug_print_source_tree(forms)
}
