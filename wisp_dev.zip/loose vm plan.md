Yeah, you’re right. I overcooked it and blurred three different stages:

```text id="8tm9h0"
current bring-up subset
future fn/closure model
possible full VM architecture
```

For what you’re actually doing — **end-to-end with `do`, `def`, `set`, builtins, maybe vectors, no `fn`, no `if` at first** — the shape is much smaller.

And yes: if you already have a tree of values, you do **not** need to invent a `Form` layer just because I said so. More on that below.

## First reset: your stage-1 Wisp is very small

Assume only:

```text id="waxgha"
literals
names
list forms as calls/special forms
do
def
set name
built-in calls
maybe vectors
```

No:

```text id="y7mfvr"
fn
closures
if
while
cells
upvalues
jump patching
imports
modules
```

Then the compiler/VM can be much simpler.

## Do you need call frames?

Yes, but only in the boring VM sense.

Even with no user functions, you probably still want one top-level frame:

```odin id="87h1mq"
CallFrame {
    proto: ^Proto,
    ip: int,
    slots_base: int,
}
```

At first, there is only one frame: the file/top-level proto.

Native built-in calls do **not** create Wisp call frames. They just receive evaluated args and return a `Value`.

So stage 1 has:

```text id="wplavv"
one proto
one running frame
slots/registers for that proto
native calls
no Wisp function calls yet
```

That gives you the VM shape without implementing the function system.

## Minimal opcode set for stage 1

You do **not** need the big list I gave.

For stage 1, something like this is enough:

```text id="nqmj7r"
LOAD_CONST dst const_index
GET_SLOT dst slot
SET_SLOT slot src
GET_GLOBAL dst global_index
SET_GLOBAL global_index src
CALL base arg_count
MAKE_VECTOR dst first_slot count       ; if vectors now
VECTOR_GET dst vector_slot index_slot  ; if vector calls now
VECTOR_SET vector_slot index_slot value_slot ; if indexed set now
RETURN src / HALT src
```

Maybe add:

```text id="7ot4ik"
MOVE dst src
```

only if your register allocator/codegen shape wants it.

That is it.

No `GET_CELL`. No `SET_CELL`. No upvalues. No closure stuff. You are deferring `fn`; cells are not stage-1.

## What the get/set ops mean

Given the current ref’s lookup model:

```text id="fr54dc"
local/body scopes -> file scope -> global environment
```

and `def`/`set` rules, you need two storage classes at stage 1. The ref says each file has its own file scope, Wisp has one global environment, and lookup checks local body scopes first, then file scope, then global environment. 

### `GET_SLOT`

Reads a compiler-known lexical/file/body slot.

This covers:

```scheme id="qymlhf"
(def x 10)
x
```

and:

```scheme id="b59ovi"
(do
  (def x 10)
  x)
```

At stage 1, file-scope bindings and `do` bindings can both be slots in the file proto’s frame. The compiler enforces where they are visible.

### `SET_SLOT`

Writes a compiler-known lexical/file/body slot.

This covers:

```scheme id="v58buq"
(def x 10)
(set x 20)
```

If `x` resolves to a file/body binding, emit `SET_SLOT`.

### `GET_GLOBAL`

Reads a global binding cell/index.

This covers built-ins:

```scheme id="k9nk97"
(+ 1 2)
```

The compiler resolves `+` to a global index, and `GET_GLOBAL` loads the current value from the mutable global environment. That still preserves monkey-patching because the index points to a global binding, not a hardwired opcode.

### `SET_GLOBAL`

Writes a global binding.

This covers:

```scheme id="2fj58p"
(set + my-plus)
```

assuming no nearer `+` exists.

### Why not one generic `GET_BIND`?

You could use:

```text id="exwnpo"
GET_BIND dst binding_ref
SET_BIND binding_ref src
```

where `binding_ref` contains kind + index.

That is honestly also fine. Internally it just branches on:

```text id="jyp068"
slot vs global
```

For KISS VM clarity, I’d probably do separate opcodes:

```text id="rxjgjr"
GET_SLOT / SET_SLOT
GET_GLOBAL / SET_GLOBAL
```

But if you want a smaller opcode list, `GET_BIND` / `SET_BIND` is valid.

## Why there are globals at all

Because built-ins are mutable global bindings in the current ref. Built-in names are not reserved; user definitions can shadow them; `set` can replace them. 

So:

```scheme id="eow0l3"
(+ 1 2)
```

must not compile to `ADD`.

It should compile to “load `+` binding, call it”:

```text id="u9o8zb"
GET_GLOBAL r0, "+"
LOAD_CONST r1, 1
LOAD_CONST r2, 2
CALL r0, 2
```

Then if later:

```scheme id="g1l959"
(def + 123)
(+ 1 2)
```

the second `+` resolves to the file slot, not the global.

That means:

```text id="yr5ncf"
before def +:
  + -> global

after def +:
  + -> slot
```

That is exactly what the compiler resolver is for.

## Your value tree is enough

You asked:

> why `Form :: struct`? I already have a tree of values, why is that not enough?

It probably **is enough** for now.

If your reader gives you:

```text id="ypp6wb"
nil/bool/int/float/string/name/list/vector
```

then the compiler can compile that directly.

You only need a separate `Form` node if your current value tree is missing something you care about, usually:

```text id="0ywtyi"
source span / line / column
distinguishing source names from future runtime symbols
distinguishing source lists from runtime list values
```

But since quote/source-as-data are deferred, and your source lists are compile-time structures right now, a value tree is fine.

So stage 1 compiler can be:

```odin id="ojcyft"
compile_expr(c, value_tree_node, dst)
```

No extra AST taxonomy.

The only thing I would still want eventually is source location on reader nodes. But that can be added to your existing tree shape if needed. It does not require a whole new `Form` layer.

## Compiler shape

Think of it as three layers.

### 1. Compiler state

```text id="y0zj0v"
Compiler
  proto builder
  current lexical scope stack
  next slot
  temp cursor
  global table reference
```

No token stream. No parser. It just walks value-tree nodes.

### 2. Resolver

The resolver answers:

```text id="l3we9w"
When I see name x here, what binding does it mean?
```

It returns:

```text id="7zvwfa"
slot binding
global binding
not found
```

For stage 1:

```text id="nvbh6x"
slot binding = file or do binding
global binding = builtin/global env entry
```

### 3. Codegen

Codegen emits bytecode from the tree.

The shape is:

```text id="ss8yr6"
compile_expr
compile_body
compile_def
compile_set
compile_call
compile_do
compile_vector maybe
```

You already said `compile_*` names feel right. I agree.

## Body compilation is the center

The important compiler operation is not “eval.” It is:

```text id="omx9jf"
compile_body(forms, dst)
```

Because Wisp has a real definition/expression split.

The ref says a body form is either a definition or an expression, empty bodies return `nil`, and non-empty bodies must end with an expression. 

So:

```text id="aagsp8"
compile_body(forms, dst):
  if empty:
    emit nil into dst

  for each form except last:
    if definition:
      compile_def(form)
    else:
      compile_expr(form, temp)
      discard temp

  final form:
    must be expression
    compile_expr(final, dst)
```

That one operation handles:

```scheme id="j8akx5"
(do
  body-form...)
```

and later:

```scheme id="jq50rg"
fn bodies
while bodies
named function bodies
```

But for stage 1, only `do`.

## Scope for `do`

For `do`:

```scheme id="e9ht6v"
(do
  (def x 10)
  (+ x 1))
```

compile:

```text id="f70pri"
enter compiler scope
compile body
leave compiler scope
```

Runtime does not necessarily need an environment object. Since there are no closures, `do` locals can just be slots.

So “scope” is mostly compile-time:

```text id="e8s9i9"
which names are visible?
are duplicate defs in this scope?
which slot does this name resolve to?
```

That’s the clean part. Wisp’s lexical scope can be compiled away into slots for the no-closure subset.

## Slot allocation

For stage 1, use slots for both permanent bindings and temporaries.

Example:

```scheme id="f7wmwa"
(do
  (def x 10)
  (+ x 1))
```

Possible slots:

```text id="zqbnzp"
slot 0 = temp/result/callee etc
slot 1 = x
slot 2 = temp arg
...
```

You can do scope marks like Kiln:

```text id="xgb7xg"
enter_scope:
  remember binding_count
  remember next_slot

leave_scope:
  pop bindings back to binding_count
  reset next_slot
```

That lets slots from a finished `do` be reused later. Since no closures, this is safe.

If you want even simpler first pass, never reuse slots and only pop bindings. But since you care, scope-mark slot reuse is straightforward and not over-architecture.

## Definition compilation

This part matters because your ref says bindings are ordered: visible only after definition has evaluated. 

For value def:

```scheme id="tigq80"
(def x expr)
```

Compile like:

```text id="rfe976"
check x is not duplicate in current scope
compile expr into temp
allocate slot for x
emit SET_SLOT x_slot temp
add x -> x_slot to resolver
```

Important: add `x` **after** compiling `expr`.

So:

```scheme id="jb6915"
(def x x)
```

does not see itself. It either resolves to an outer `x`, or errors if none exists.

That matches ordered bindings.

## Set compilation

For stage 1, just support name `set` first:

```scheme id="jfp1l8"
(set x expr)
```

Compile:

```text id="zfnum8"
resolve x
if missing: error
compile expr into temp
if x is slot: emit SET_SLOT
if x is global: emit SET_GLOBAL
result of set is assigned value
```

Since `set` is an expression special form and returns the assigned value, if caller wants result in `dst`, either compile expr directly to `dst` then store from `dst`, or compile temp/store/move.

Example:

```text id="mlbxeq"
compile expr -> dst
SET_SLOT slot, dst
```

Good.

## Call compilation

Calls are uniform.

For:

```scheme id="26bo77"
(+ 1 2)
```

compile:

```text id="3r6uje"
compile callee into base
compile arg1 into base + 1
compile arg2 into base + 2
CALL base 2
```

Let `CALL` replace `base` with the return value.

That is a very Kiln-ish VM shape without copying Kiln’s parser.

So after call:

```text id="bfzmt2"
slot base = result
```

If caller wanted result somewhere else, use `MOVE`.

## Built-ins

Built-ins are native function values stored in the global environment.

So:

```text id="tc9y3b"
GlobalBinding {
  name
  value: Value(native_function_object)
}
```

`CALL` sees callee is native and calls Odin proc:

```odin id="8io9e2"
NativeFn :: proc(vm: ^VM, args: []Value) -> (Value, Runtime_Error)
```

No user call frames yet.

## Vectors, if you include them

Vector literal:

```scheme id="rycpji"
[1 x (+ 1 2)]
```

compile elements left-to-right into contiguous temp slots, then:

```text id="78irb1"
MAKE_VECTOR dst first_elem_slot count
```

Vector call can either go through generic `CALL` because vectors are callable values in the ref, or you can lower it specially only when callee syntactically compiles to vector? I would keep generic `CALL`:

```scheme id="td8e6w"
(v 1)
```

compiles like any call:

```text id="ycptmw"
GET_SLOT base, v
LOAD_CONST base+1, 1
CALL base, 1
```

At runtime `CALL` dispatches:

```text id="p4yfku"
native function -> call native
vector -> index
else -> error
```

That is clean and keeps the “callable vector” semantics honest.

Indexed `set` can wait. If you include it, yes, you need `VECTOR_SET`.

## What not to design yet

For this bring-up, do not design:

```text id="4kax4g"
cells
upvalues
closure conversion
file-env lifetime
named function recursion
jump patching
while scope runtime
if branch patching
```

Those belong to later stages.

The only future-compatible thing to keep is this internal abstraction:

```text id="xatocq"
BindingRef = Slot(index) | Global(index)
```

Later it can become:

```text id="vbc52w"
Slot(index)
Global(index)
FileCell(index)
Upvalue(index)
CapturedCell(index)
```

But stage 1 only needs slot/global.

## Direct answer

For your current subset, the right high-level shape is:

```text id="if5xil"
read value tree
compile value tree to bytecode
run bytecode in one top-level call frame
use slots for file/do bindings and temps
use global binding indexes for builtins
compile calls uniformly
do scope is compile-time slot visibility
def adds a slot after RHS compile
set writes resolved slot/global
```

That is the KISS slot VM path.

It is not copying Kiln wholesale. It is taking the durable VM pattern — proto, slots, constants, call base, native calls — and deleting everything Wisp does not need yet.
